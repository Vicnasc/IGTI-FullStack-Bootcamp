import axios from 'axios';

export default axios.create({
  baseURL: 'https://pokemon-back-api.herokuapp.com/',
  headers: {
    'Content-type': 'application/json',
  },
});
